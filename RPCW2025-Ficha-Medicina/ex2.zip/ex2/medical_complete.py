import csv 
import json 
import shutil 
symptom_list = []
disease_symptoms = {}
shutil.copy2("medical.ttl", "medical_inferido.ttl")

with open("Disease_Syntoms.csv", "r") as fin:
    reader = csv.DictReader(fin)
    #print(reader.fieldnames)

    for row in reader:
        disease = row["Disease"]
        symptoms = set()
        
        # Coletar todos os sintomas não vazios da linha (Symptom_1 a Symptom_17)
        for i in range(1, 18):
            symptom = row.get(f"Symptom_{i}", "").strip()
            if symptom:  # Ignora strings vazias
                symptom = symptom.replace(" ", "_")
                symptom = symptom.replace("(", "_")
                symptom = symptom.replace(")", "_")
                symptoms.add(symptom)
                if symptom not in symptom_list:
                    symptom_list.append(symptom)
        
        # Atualiza o dicionário: se a doença já existe, adiciona novos sintomas
        if disease:
            disease = disease.replace(" ", "_")
            disease = disease.replace("(", "_")
            disease = disease.replace(")", "_")
        if disease in disease_symptoms:
            disease_symptoms[disease].update(symptoms)
        else:
            disease_symptoms[disease] = symptoms

        




#print(disease_symptoms)

# Exemplo 
#:Flu a :Disease ;
#   :hasSymptom :Fever, :Cough, :SoreThroat ;

symptom_data = ""
for symptom in symptom_list:
    symptom_data += f""":{symptom} a :Symptom.\n"""
diasease_data = ""

for disease, symptoms in disease_symptoms.items():
    diasease_data += f""":{disease} a :Disease ;
        :hasSymptom {", ".join([f":{s}" for s in symptoms])}.\n"""

# Print the generated data
#print(symptom_data)
#print(diasease_data)
# Output the data to a file
with open("medical_inferido.ttl", "a") as f:
    f.write(symptom_data)
    f.write(diasease_data)
   


